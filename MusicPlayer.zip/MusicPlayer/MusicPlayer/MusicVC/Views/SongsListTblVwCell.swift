//
//  SongsListTblVwCell.swift
//  MusicPlayer
//
//  Created by Venga Babu on 27/10/23.
//

import UIKit

class SongsListTblVwCell: UITableViewCell {

    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var artist: UILabel!
    @IBOutlet weak var songName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func updateTheContent(content: SongModel) {
        self.artist.text = content.artist
        self.songName.text = content.title 
    }
}
